package com.softtek.ja.hms.domain;

import com.softtek.ja.hms.helper.Constant;
import com.softtek.ja.hms.helper.OperationDB;
import com.softtek.ja.hms.interfaces.IOperations;

public class Accountant extends Employee implements IOperations {

	public Accountant() {
	}

	public void add() {
		OperationDB.addEmployee();
	}

	@Override
	public void delete() {
		OperationDB.readEmployee(Constant.ACCOUNTANT_READ_QUERY);
		System.out.println(
				"\n----------------------------------------------\nPlease Select the Accountant record to delete\n----------------------------------------------\n");
		OperationDB.deleteEmployee();
	}

	@Override
	public void update() {
		OperationDB.updateEmployee();
	}

	@Override
	public void read() {
		OperationDB.readEmployee(Constant.ACCOUNTANT_READ_QUERY);
	}
}
