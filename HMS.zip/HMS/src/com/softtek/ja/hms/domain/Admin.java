package com.softtek.ja.hms.domain;

import com.softtek.ja.hms.helper.Constant;
import com.softtek.ja.hms.helper.OperationDB;
import com.softtek.ja.hms.interfaces.IOperations;

public class Admin extends Employee implements IOperations {
	public Admin() {

	}

	@Override
	public void add() {
		OperationDB.addEmployee();
	}

	@Override
	public void delete() {
		OperationDB.readEmployee(Constant.ADMIN_READ_QUERY);
		System.out.println(
				"\n----------------------------------------------\nPlease Select the Admin record to delete\n----------------------------------------------\n");
		OperationDB.deleteEmployee();
	}

	@Override
	public void update() {
		OperationDB.updateEmployee();
	}

	@Override
	public void read() {
		OperationDB.readEmployee(Constant.ADMIN_READ_QUERY);
	}
}
