package com.softtek.ja.hms.domain;

import com.softtek.ja.hms.helper.Constant;
import com.softtek.ja.hms.helper.OperationDB;
import com.softtek.ja.hms.interfaces.IOperations;

public class Chef extends Employee implements IOperations {
	private String chefId;
	private String tableId;
	Employee emp;
	OperationDB odb;

	// Empty Constructor
	public Chef() {
	}

	// parameterized Constructor
	public Chef(String tableId) {
		this.chefId = emp.getEmpId();
		this.tableId = tableId;
	}

	public String getServerId() {
		return chefId;
	}

	public String getTableId() {
		return tableId;
	}

	// All the CRUD operation methods
	@Override
	public void add() {
		OperationDB.addEmployee();
	}

	@Override
	public void delete() {
		OperationDB.readEmployee(Constant.CHEF_READ_QUERY);
		System.out.println(
				"\n----------------------------------------------\nPlease Select the Chef record to delete\n----------------------------------------------\n");
		OperationDB.deleteEmployee();
	}

	@Override
	public void update() {
		OperationDB.updateEmployee();
	}

	@Override
	public void read() {
		OperationDB.readEmployee(Constant.CHEF_READ_QUERY);
	}
}
