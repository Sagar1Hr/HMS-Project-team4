package com.softtek.ja.hms.domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.softtek.ja.hms.helper.Constant;
import com.softtek.ja.hms.helper.OrderDB;
import com.softtek.ja.hms.interfaces.IOperations;

public class Customer implements IOperations {

	// All the CUstomer Attributes as the Instance variables
	private String customerId;
	private String customerName;
	private String cEmail;
	private Long cMobile;

	public OrderDB order = new OrderDB();

	// Empty Constructor
	public Customer() {

	}

	// parameterized Constructor
	public Customer(String customerName, String cEmail, long cMobile) {
		this.customerName = customerName;
		this.customerId = "C" + setId();
		this.cEmail = cEmail;
		this.cMobile = cMobile;
	}

	public Customer(String CId, String cName, String Email, String cMobile) {
		this.customerName = cName;
		this.customerId = CId;
		this.cEmail = Email;
		this.cMobile = Long.parseLong(cMobile);
	}

	public String getCustomerId() {
		return customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getcEmail() {
		return cEmail;
	}

	public Long getcMobile() {
		return cMobile;
	}

	// Auto Generating the EmpID from the previous data of the CUSTOMER table from
	// the database
	public static int setId() {
		Connection connect;
		PreparedStatement statement;
		try {
			Class.forName(Constant.DRIVER);
		} catch (ClassNotFoundException cnfe) {
			System.err.println("ClassNotFoundException : " + cnfe);
		}
		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement("select CId from customer ORDER BY CId DESC LIMIT 1");
			ResultSet rs1 = statement.executeQuery();
			rs1.next();
			String cId = rs1.getString("CId");
			int c = cId.charAt(cId.length() - 1);
			int num = c - 47;
			return num;
		} catch (SQLException e) {
			System.out.println(e);
		}
		return 1;
	}

	// all CRUD Operation Methods
	@Override
	public void add() {
		order.takeCustomerDetails();
	}

	@Override
	public void delete() {

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void read() {
		OrderDB.readCustomer();

	}

}
