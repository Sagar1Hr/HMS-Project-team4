package com.softtek.ja.hms.domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.softtek.ja.hms.helper.AdminHelper;
import com.softtek.ja.hms.helper.Constant;

public class Employee {

	// All the Attributes of the Employee Class
	private String empName;
	private String empId;
	private int age;
	private long mobileNo;
	private String designation;
	private String DsId;
	private String address;
	private double salary;

	// Empty Constructor
	public Employee() {
	}

	// Parameterized Constructor
	public Employee(String empName, int age, long mobileNo, String designation, String address) {
		this.empName = empName;

		// Auto generating code for EmpID
		this.empId = "E" + setId();
		this.age = age;
		this.mobileNo = mobileNo;
		this.designation = designation;
		this.DsId = AdminHelper.dsIdAssign(designation);
		this.address = address;
		this.salary = AdminHelper.assignSalary(DsId);
	}

	public String getEmpName() {
		return empName;
	}

	public String getEmpId() {
		return empId;
	}

	public int getAge() {
		return age;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public String getDesignation() {
		return designation;
	}

	public String getDsId() {
		return DsId;
	}

	public String getAddress() {
		return address;
	}

	// Auto Generating the EmpID from the previous data of the EMPLOYEE table from
	// the database
	public static int setId() {
		Connection connect;
		PreparedStatement statement;
		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement("select EmpId from employee ORDER BY EmpId DESC LIMIT 1");
			ResultSet rs1 = statement.executeQuery();
			rs1.next();
			String EmpId = rs1.getString("EmpId");
			int c = EmpId.charAt(EmpId.length() - 1);
			int num = c - 47;
			return num;
		} catch (SQLException e) {
			System.out.println(e);
		}
		return 1;
	}

	@Override
	public String toString() {
		return "Employee [empName=" + empName + ", empId=" + empId + ", age=" + age + ", mobileNo=" + mobileNo
				+ ", designation=" + designation + ", DsId=" + DsId + ", address=" + address + "]";
	}

	public double getSalary() {
		return salary;
	}

}
