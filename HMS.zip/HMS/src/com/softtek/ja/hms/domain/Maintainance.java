package com.softtek.ja.hms.domain;

import com.softtek.ja.hms.helper.Constant;
import com.softtek.ja.hms.helper.OperationDB;
import com.softtek.ja.hms.interfaces.IOperations;

public class Maintainance extends Employee implements IOperations {
	private String maintainanceId;
	Employee emp;
	OperationDB odb;

	// Empty Constructor
	public Maintainance() {
		// TODO Auto-generated constructor stub
	}

	// parameterized Constructor
	public Maintainance(String tableId) {
		this.maintainanceId = emp.getEmpId();
	}

	// All the CRUD operation methods
	@Override
	public void add() {
		OperationDB.addEmployee();
	}

	@Override
	public void delete() {
		OperationDB.readEmployee(Constant.MAINTAINANCE_READ_QUERY);
		System.out.println(
				"\n----------------------------------------------\nPlease Select the Maintenace record to delete\n----------------------------------------------\n");
		OperationDB.deleteEmployee();
	}

	@Override
	public void update() {
		OperationDB.updateEmployee();
	}

	public String getMaintainanceId() {
		return maintainanceId;
	}

	@Override
	public void read() {
		OperationDB.readEmployee(Constant.MAINTAINANCE_READ_QUERY);
	}

}
