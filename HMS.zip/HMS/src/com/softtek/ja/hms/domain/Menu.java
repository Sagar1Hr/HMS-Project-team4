package com.softtek.ja.hms.domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.softtek.ja.hms.helper.Constant;

public class Menu {

	// All the Menu Attributes as the instance variables
	private String strFoodId;
	private String strFoodName;
	private String strFoodType;
	private double dbPrice;

	// Empty constructor
	public Menu() {

	}

	// parameterized constructor
	public Menu(String strFoodName, String strFoodType, double dbPrice) {

		this.strFoodName = strFoodName;
		this.strFoodType = strFoodType;
		if (strFoodType.equals("VEG")) {
			this.strFoodId = "V" + setId(strFoodType);
		} else {
			this.strFoodId = "N" + setId(strFoodType);
		}
		this.dbPrice = dbPrice;
	}

	// All the Getter Methods
	public String getStrFoodName() {
		return strFoodName;
	}

	public double getDbPrice() {
		return dbPrice;
	}

	public String getStrFoodId() {
		return strFoodId;
	}

	public String getStrFoodType() {
		return strFoodType;
	}

	// Method to retrieve the last Food Id and get the last Number.
	public static int setId(String foodType) {
		Connection connect;
		PreparedStatement statement;
		try {
			Class.forName(Constant.DRIVER);
		} catch (ClassNotFoundException cnfe) {
			System.err.println("ClassNotFoundException : " + cnfe);
		}
		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement(Constant.SETFOODID_QUERY);
			statement.setString(1, foodType);

			ResultSet rs1 = statement.executeQuery();
			rs1.next();
			String cId = rs1.getString("FId");
			int c = cId.charAt(cId.length() - 1);
			int num = c - 47;// ASCII Value of the number '1' is 49 to get next number 47 has to be
								// subtracted
			return num;
		} catch (SQLException e) {
			System.out.println(e);
		}
		return 1;
	}

	@Override
	public String toString() {
		return "Menu [strFoodId=" + strFoodId + ", strFoodName=" + strFoodName + ", strFoodType=" + strFoodType
				+ ", dbPrice=" + dbPrice + "]";
	}

}
