package com.softtek.ja.hms.domain;

import com.softtek.ja.hms.helper.OperationDB;
import com.softtek.ja.hms.interfaces.IOperations;

public class NonVeg extends Menu implements IOperations {
	public static String strFtype = "NVEG";

	//Methods to perform the CRUD Operations
	@Override
	public void add() {
		OperationDB.addMenuItem(strFtype);
	}

	@Override
	public void delete() {
		OperationDB.deleteMenuItem();
	}

	@Override
	public void update() {
		OperationDB.updateItem();
	}

	@Override
	public void read() {
		OperationDB.readItem();

	}
}
