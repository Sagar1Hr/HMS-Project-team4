package com.softtek.ja.hms.domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.softtek.ja.hms.helper.Constant;
import com.softtek.ja.hms.interfaces.IOperations;

public class Order implements IOperations {

	// All Order Attributes as Instance variable
	private String orderId;
	private String customerId;
	private int tableId;
	private String customerName;
	private double totalPrice;

	// Empty Constructor
	public Order() {

	}

	// Parameterized Constructor
	public Order(int tableId, String customerId, String customerName, double totalPrice) {
		this.customerName = customerName;
		this.orderId = "O" + setId();
		this.totalPrice = totalPrice;
		this.customerId = customerId;
		this.tableId = tableId;
	}

	public String getOrderId() {
		return orderId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public int getTableId() {
		return tableId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	// Auto Generating the EmpID from the previous data of the BILL table from
	// the database
	public static int setId() {
		Connection connect;
		PreparedStatement statement;
		try {
			Class.forName(Constant.DRIVER);
		} catch (ClassNotFoundException cnfe) {
			System.err.println("ClassNotFoundException : " + cnfe);
		}
		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement("select OId from bill ORDER BY OId DESC LIMIT 1");
			ResultSet rs1 = statement.executeQuery();
			rs1.next();
			String oId = rs1.getString("OId");
			int c = oId.charAt(oId.length() - 1);
			int num = c - 47;
			return num;
		} catch (SQLException e) {
			System.out.println(e);
		}
		return 1;
	}

	// All Crud Operations
	@Override
	public void add() {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void read() {
		// TODO Auto-generated method stub

	}

}
