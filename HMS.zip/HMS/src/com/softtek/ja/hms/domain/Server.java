package com.softtek.ja.hms.domain;

import java.util.Scanner;

import com.softtek.ja.hms.helper.Constant;
import com.softtek.ja.hms.helper.OperationDB;
import com.softtek.ja.hms.interfaces.IOperations;

public class Server extends Employee implements IOperations {
	private String tableId;
	Employee emp;
	OperationDB odb;

	Scanner scan = new Scanner(System.in);

	public Server() {
	}

	public String getTableId() {
		return tableId;
	}

	// All the Crud operations
	@Override
	public void add() {
		OperationDB.addEmployee();
	}

	@Override
	public void delete() {
		OperationDB.readEmployee(Constant.SERVER_READ_QUERY);
		System.out.println(
				"\n----------------------------------------------\nPlease Select the Server record to delete\n----------------------------------------------\n");
		OperationDB.deleteEmployee();
	}

	@Override
	public void update() {
		OperationDB.updateEmployee();
	}

	@Override
	public void read() {
		OperationDB.readEmployee(Constant.SERVER_READ_QUERY);
	}
}
