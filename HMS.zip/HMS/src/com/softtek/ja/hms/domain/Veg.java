
package com.softtek.ja.hms.domain;

import com.softtek.ja.hms.helper.OperationDB;
import com.softtek.ja.hms.interfaces.IOperations;

public class Veg extends Menu implements IOperations {
	public static String strFtype = "VEG";
	
	//Methods to perform the CRUD Operations
	@Override
	public void add() {
		OperationDB.addMenuItem(strFtype);
	}

	@Override
	public void delete() {
		OperationDB.deleteMenuItem();
	}

	@Override
	public void update() {
	}

	@Override
	public void read() {
		OperationDB.readItem();
	}

}
