package com.softtek.ja.hms.driver;

import com.softtek.ja.hms.helper.Constant;
//import com.softtek.ja.hms.operation.FinanceOperation;
//import com.softtek.ja.hms.helper.OperationDB;
//import com.softtek.ja.hms.helper.OrderHelper;
//import com.softtek.ja.hms.operation.FinanceOperation;
//import com.softtek.ja.hms.helper.OrderDB;
import com.softtek.ja.hms.operation.Hotel;

// DriverClass starting 
public class DriverClass {
	static Hotel hotel = new Hotel();

	// Main Method to start the execution.
	public static void main(String[] args) {

		Constant.driverMethod();
		hotel.hotelExecute();

	}
}
