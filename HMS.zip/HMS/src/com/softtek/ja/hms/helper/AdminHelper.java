package com.softtek.ja.hms.helper;

import java.time.LocalTime;
import java.util.Scanner;

import com.softtek.ja.hms.operation.HotelOperation;

//Admin Helper class where all the methods as public and static in nature
public class AdminHelper {

	// Method to check if the hotel is open or not.
	public static boolean open() {
		// Providing the Time Range from 6am To 9pm
		LocalTime time1 = LocalTime.parse("06:00:00");// 6 AM
		LocalTime time2 = LocalTime.parse("21:00:00");// 9 PM
		LocalTime now = LocalTime.now();

		// Storing compareTo Results
		int value1 = now.compareTo(time1);
		int value2 = now.compareTo(time2);

		// Check Condition
		if (value1 == 1 && value2 == -1) {
			System.out.println("Welcome to Hotel Portal");
			return true;
		} else {
			System.out.println("Hotel is Closed \nPlease Visit After 6 AM");
			return false;
		}

	}

	// TO check the login details and validate them
	public static boolean loginValidation(String user, String psd) {
		boolean flag = true;
		while (flag) {
			if (user.equals(Constant.USER)) {
				if (psd.equals(Constant.PSD)) {
					flag = false;
					return true;
				} else {
					System.out.println("Invalid password");
				}
			}
			System.out.println("Invalid User\n");
			HotelOperation.login();
			flag = false;
		}
		return false;
	}

	// Method to assign the DSID for the employees based on the designation
	public static String dsIdAssign(String designation) {
		String jobRole = "";
		switch (designation) {
		case Constant.JOB_SERVER:
			jobRole = Constant.SERVER_ID;
			break;
		case Constant.JOB_CHEF:
			jobRole = Constant.CHEF_ID;
			break;
		case Constant.JOB_MAINTAINANCE:
			jobRole = Constant.MAINTAINANCE_ID;
			break;
		case Constant.JOB_ACCOUNTANT:
			jobRole = Constant.ACCOUNTANT_ID;
			break;
		}
		return jobRole;
	}

	// Method to validate the Mobile number
	public static long MobileNumberValidation() {
		@SuppressWarnings("resource")
		Scanner phno = new Scanner(System.in);
		long mobile = 0l;
		boolean pFlag = true;
		while (pFlag) {
			System.out.print("Mobile       : ");
			String mobNo = phno.nextLine();
			if (mobNo.length() == 10 && mobNo.matches("[0-9]*")) {
				pFlag = false;
				mobile = Long.parseLong(mobNo);
				return mobile;
			} else {
				System.out.println("Invalid Phone Number");
				MobileNumberValidation();
			}
		}
		return mobile;
	}

	// To check the age of the employee is eligible or not.
	public static int checkAge() {
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		System.out.println("Age          : ");
		int age = scan.nextInt();
		if (age >= 18) {
			return age;
		} else {
			checkAge();
		}
		return age;

	}

	public static double assignSalary(String DsId) {
		if (DsId.equalsIgnoreCase(Constant.SERVER_ID)) {
			return 14000.0;
		} else if (DsId.equalsIgnoreCase(Constant.MAINTAINANCE_ID)) {
			return 18000.0;
		} else {
			return 25000.0;
		}
	}

}
