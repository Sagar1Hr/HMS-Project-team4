package com.softtek.ja.hms.helper;

public class Constant {

	// All the queries and constant and final values.
	public static final String USER = "Admin";
	public static final String PSD = "SOFTTEK";

	public static final String[] FINANCE_USER = { "SAGAR", "NETAJI" };
	public static final String[] FINANCE_PSD = { "SAMFLYNN", "NETAJI" };

	public static final String JOB_SERVER = "SERVER";
	public static final String JOB_CHEF = "CHEF";
	public static final String JOB_MAINTAINANCE = "MAINTAINANCE";
	public static final String JOB_ACCOUNTANT = "ACCOUNTANT";
	public static final String JOB_ADMIN = "ADMIN";

	public static final String SERVER_ID = "SER";
	public static final String CHEF_ID = "CHF";
	public static final String MAINTAINANCE_ID = "MTN";
	public static final String ACCOUNTANT_ID = "ACC";
	public static final String ADMIN_ID = "ADM";

	public static final double CGST = 4.80;
	public static final double SGST = 4.80;

	public static final String URL = "jdbc:mysql://localhost:3306/hms";
	public static final String DRIVER = "com.mysql.cj.jdbc.Driver";

	public static final String EMPDELETEQUERY = "delete from employee where EmpId=?";
	public static final String EMPINSEERTQUERY = "insert into employee values(?,?,?,?,?,?,?)";
	public static final String MENUINSERTQUERY = "insert into menu values(?,?,?,?)";
	public static final String MENUDELETEQUERY = "delete from menu where FId=?";

	public static final String SERVER_READ_QUERY = "select * from employee where dsId = 'SER'";
	public static final String ACCOUNTANT_READ_QUERY = "select * from employee where dsId = 'ACC'";
	public static final String CHEF_READ_QUERY = "select * from employee where dsId = 'CHF'";
	public static final String MAINTAINANCE_READ_QUERY = "select * from employee where dsId = 'MTN'";
	public static final String ADMIN_READ_QUERY = "select * from employee where dsId = 'ADM'";

	public static final String SETFOODID_QUERY = "select FId from menu where FType = ?  ORDER BY FId DESC LIMIT 1";

	public static final String strreadallitemQuery = "select * from menu";
	public static final String strreadItemQuery = "select * from menu where FId=?";
	public static final String strreadItemVegQuery = "select * from menu where FType = 'Veg'";
	public static final String strreadItemNonVegQuery = "select * from menu where FType ='NVeg'";

	public static final String updatePriceQuery = "UPDATE menu SET FPrice = ? WHERE FId = ?";

	public static final String CUSINSEERTQUERY = "insert into customer values(?,?,?,?)";
	public static final String TABLEDISPLAY = "select * from tablelist";
	public static final String ItemsDISPLAY = "select * from items";
	public static final String tableListUpdateNAQuery = "UPDATE tablelist SET Availibility = ? where TID = ? ";
	public static final String finaltableListUpdateQuery = "UPDATE tablelist SET Availibility = 'yes'";

	public static final String READCustomerQuery = "Select * from customer";
	public static final String getLastTableId = "select TID from tablelist  ORDER BY TID DESC LIMIT 1";
	public static final String insertfeedbackQUERY = "insert into feedback(CId, ratings , cusfeedback) values(?,?,?)";

	public static final String getFinancetabledata = "select * from hotelfinance";
	public static final String getTotalAmountfromBilltable = "select sum(totalP) as amount from bill;";
	public static final String updateRawMeterialAmount = "update hotelfinance set TotalAmount = TotalAmount - ? where FinanceId=1001;";
	public static final String updateElectricityAmount = "update hotelfinance set TotalAmount = TotalAmount - ? where FinanceId=1002;";
	public static final String updateExpensesAmount = "update hotelfinance set TotalAmount = TotalAmount - ? where FinanceId=1003;";
	public static final String updateRevenueAmount = "update hotelfinance set TotalAmount = TotalAmount + ? where FinanceId=1004;";

	public static void driverMethod() {
		try {
			Class.forName(Constant.DRIVER);
		} catch (ClassNotFoundException cnfe) {
			System.err.println("ClassNotFoundException : " + cnfe);
		}
	}

}
