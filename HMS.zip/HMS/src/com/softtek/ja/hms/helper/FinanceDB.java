package com.softtek.ja.hms.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FinanceDB {
	Connection connect;
	PreparedStatement statement, statement1;

	public void getFinaceReport() {
		System.out.println("====================================");
		try {

			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			statement = connect.prepareStatement(Constant.getFinancetabledata);
			ResultSet rs1 = statement.executeQuery();
			System.err.println("\nFinanceType           Amount");
			while (rs1.next()) {

				System.out.printf("%-22s%-10s \n", rs1.getString("FeildType"), rs1.getString("TotalAmount"));
			}
			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateFinaceReport() {
		boolean UpdateFinanceFlag = true;
		while (UpdateFinanceFlag) {
			System.out.println("\n====================================");
			System.out.println(
					"1 : 1001 : RawMaterial\n2 : 1002 : Electricity\n3 : 1003 : Expenses\n4 : 1004 : Revenue\n5 : Go Back");
			int UpdateFinanceOption = Integer.parseInt(OrderHelper.switchValidator());
			switch (UpdateFinanceOption) {
			case 1:
				try {
					System.out.println("RawMaterial Cost Amount :");
					double amount = Double.parseDouble(OrderHelper.AmountValidator());
					connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
					statement = connect.prepareStatement(Constant.updateRawMeterialAmount);
					statement.setDouble(1, amount);
					statement.executeUpdate();
					System.out.println("Raw Materials Amount Updated");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				System.out.println("\n====================================");

				break;
			case 2:
				try {
					System.out.println("\nElectricity Cost Amount :");
					double amount = Double.parseDouble(OrderHelper.AmountValidator());
					connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
					statement = connect.prepareStatement(Constant.updateElectricityAmount);
					statement.setDouble(1, amount);
					statement.executeUpdate();
					System.out.println("Electricity Amount Updated");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				System.out.println("\n====================================");

				break;

			case 3:
				try {
					System.out.println("\nExpenses Amount :");
					double amount = Double.parseDouble(OrderHelper.AmountValidator());
					connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
					statement = connect.prepareStatement(Constant.updateExpensesAmount);
					statement.setDouble(1, amount);
					statement.executeUpdate();
					System.out.println("Expenses Amount Updated");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				System.out.println("\n====================================");

				break;

			case 4:
				try {
					// Getting the total sum of all bills from a single day.
					connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
					statement = connect.prepareStatement(Constant.getTotalAmountfromBilltable);
					ResultSet rs1 = statement.executeQuery();
					rs1.next();

					double amount = rs1.getDouble("amount");
					System.out.println("Revenue Amount : " + amount);
					// Updating the Revenue amount by adding it to the revenue amount.
					statement1 = connect.prepareStatement(Constant.updateRevenueAmount);
					statement1.setDouble(1, amount);
					statement1.executeUpdate();
					System.out.println("Revenue Amount Updated");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				System.out.println("\n====================================");

				break;
			case 5:
				UpdateFinanceFlag = false;
				break;

			default:
				System.out.println("Invalid Option");
				updateFinaceReport();
				break;
			}
		}

	}

}
