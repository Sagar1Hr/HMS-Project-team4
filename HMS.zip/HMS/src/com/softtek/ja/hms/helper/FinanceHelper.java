package com.softtek.ja.hms.helper;

public class FinanceHelper {

	public static boolean financeLoginValidator(String username, String password) {
		if (Constant.FINANCE_USER[0].equals(username)) {
			if (Constant.FINANCE_PSD[0].equals(password)) {
				return true;
			}
		} else if (Constant.FINANCE_USER[0].equals(username)) {
			if (Constant.FINANCE_PSD[0].equals(password)) {
				return true;
			}
		}
		return false;
	}
}
