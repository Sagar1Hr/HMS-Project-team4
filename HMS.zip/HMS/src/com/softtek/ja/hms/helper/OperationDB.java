package com.softtek.ja.hms.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.softtek.ja.hms.domain.Employee;
import com.softtek.ja.hms.domain.Menu;

public class OperationDB {
	static Scanner scan = new Scanner(System.in);
	Employee emp;

	static Connection connect;
	static PreparedStatement statement;

	// Method to add the new employee details into the database.
	public static void addEmployee() {

		// Taking the employee essential data from the employee from the console.
		System.out.println("Enter the Server Details");

		String ename = OrderHelper.nameValidator();
		int age = AdminHelper.checkAge();
		long mobile = AdminHelper.MobileNumberValidation();
		System.out.print("Designation  : ");
		String design = scan.next();
		System.out.print("Address      : ");
		String address = scan.next();
		Employee emp = new Employee(ename, age, mobile, design, address);

		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement(Constant.EMPINSEERTQUERY);
			statement.setString(1, emp.getEmpId());
			statement.setString(2, emp.getEmpName());
			statement.setInt(3, emp.getAge());
			statement.setString(4, emp.getDsId());
			statement.setLong(5, emp.getMobileNo());
			statement.setString(6, emp.getAddress());
			statement.setDouble(7, emp.getSalary());

			statement.executeUpdate();
			System.out.println("Inserted Successfully");

			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to delete the employee record from the database based on the EmpId.
	public static void deleteEmployee() {
		System.out.print("Enter the Emp id : ");
		String empdel = scan.next();

		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement(Constant.EMPDELETEQUERY);
			statement.setString(1, empdel.toUpperCase());
			statement.executeUpdate();
			System.out.println("Deleted Successfully");

			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to read the data from the database using resultSet.
	public static void readEmployee(String readAllquery) {
		String readquery = "select * from employee where EmpId=?";

		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			// Code to choose and display all the records, individual info or back to main
			boolean repeatflag = true;
			while (repeatflag) {
				System.out.print("1. Display All\n2. Fetch individual info \n3. Back \n");
				int option = Integer.parseInt(OrderHelper.switchValidator());
				switch (option) {
				case 1:
					statement = connect.prepareStatement(readAllquery);
					ResultSet rs = statement.executeQuery();
					System.out.println("====================================================");
					while (rs.next()) {
						System.out.println(rs.getString("Empid") + " " + rs.getString("Name") + " "
								+ rs.getString("Age") + " " + rs.getString("DsId") + " " + rs.getString("Mobile") + " "
								+ rs.getString("Address") + " " + rs.getString("EmpSalary"));
					}
					System.out.println("====================================================");

					break;
				case 2:
					statement = connect.prepareStatement(readquery);
					System.out.print("Enter the Emp id : ");
					String empread = scan.next();
					statement.setString(1, empread);
					ResultSet rs1 = statement.executeQuery();
					System.out.println("====================================================");
					while (rs1.next()) {
						System.out.println(rs1.getString("Empid") + " " + rs1.getString("Name") + " "
								+ rs1.getString("Age") + " " + rs1.getString("DsId") + " " + rs1.getString("Mobile")
								+ " " + rs1.getString("Address") + " " + rs1.getString("EmpSalary"));
					}
					System.out.println("====================================================");

					break;
				case 3:
					repeatflag = false;
					break;
				}
			}
			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static void displayEmployee(String dsId) {
		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement("Select * from employee where DsId = ? ");
			statement.setString(1, dsId);
			ResultSet rs = statement.executeQuery();
			System.out.println("====================================================");
			while (rs.next()) {
				System.out.println(rs.getString("Empid") + " " + rs.getString("Name") + " " + rs.getString("Age") + " "
						+ rs.getString("DsId") + " " + rs.getString("Mobile") + " " + rs.getString("Address") + " "
						+ rs.getString("EmpSalary"));
			}
			System.out.println("====================================================");

			statement.close();
			connect.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to update the employee data
	// Update the name or Mobile Number or Update address or back
	public static void updateEmployee() {
		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			boolean repeatFlag = true;
			while (repeatFlag) {
				System.out.print("\n1. Update Name \n2. Update Mobile Number \n3. Update Address \n4. Back \n");
				int option = Integer.parseInt(OrderHelper.switchValidator());
				System.out.print("\nEnter the Emp id : ");
				String Empid = scan.next();
				switch (option) {
				case 1:
					String updatequery = "UPDATE employee SET Name = ? WHERE Empid = ?";
					System.out.print("Enter the new Name : ");
					String name = scan.next();
					statement = connect.prepareStatement(updatequery);
					statement.setString(1, name);
					statement.setString(2, Empid);
					statement.executeUpdate();
					System.out.println("Successfully Updated Employees Name.");
					break;
				case 2:
					String updatequery1 = "UPDATE employee SET Mobile = ? WHERE Empid = ?";
					System.out.print("Enter the new Mobile Number : ");
					String Mobile = scan.next();
					statement = connect.prepareStatement(updatequery1);
					statement.setString(1, Mobile);
					statement.setString(2, Empid);
					statement.executeUpdate();
					System.out.println("Successfully Updated Employees Mobile Number.");
					break;

				case 3:
					String updatequery2 = "UPDATE employee SET Address = ? WHERE Empid = ?";
					System.out.print("Enter the new Address : ");
					String address = scan.next();
					statement = connect.prepareStatement(updatequery2);
					statement.setString(1, address);
					statement.setString(2, Empid);
					statement.executeUpdate();
					System.out.println("Successfully Updated Employees Address.");
					break;

				case 4:
					repeatFlag = false;
					break;

				default:
					System.out.println("Invalid Emp Id!!!");
					break;
				}
			}

			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// Method to add the Menu Items to the Menu Table in database
	public static void addMenuItem(String strFtype) {

		// Taking the food Item details from the console
		System.out.println("Enter the Item Details");
		System.out.print("ITEM      : ");
		String item = scan.nextLine();
		System.out.print("PRICE     : ");
		double price = scan.nextDouble();
		Menu m = new Menu(item, strFtype, price);
		System.out.println(m.toString());

		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			System.out.println("2");
			statement = connect.prepareStatement(Constant.MENUINSERTQUERY);
			statement.setString(1, m.getStrFoodId());
			statement.setString(2, m.getStrFoodName());
			statement.setString(3, m.getStrFoodType());
			statement.setDouble(4, m.getDbPrice());
			System.out.println("3");
			statement.executeUpdate();
			System.out.println("Inserted Successfully");

			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to delete the Menu Item record from the Menu table in the database
	// based on the food Id
	public static void deleteMenuItem() {
		System.out.print("Enter the Item id : ");
		String itemId = scan.next();

		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement(Constant.MENUDELETEQUERY);
			statement.setString(1, itemId.toUpperCase());
			statement.executeUpdate();
			System.out.println("Deleted Successfully");

			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to read or displaying the Menu Items
	// Displaying all or Veg Items or NonVeg Items or Fetch Individual Item
	public static void readItem() {

		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			boolean repeatflag = true;
			while (repeatflag) {
				System.out
						.print("1. Display All\n2. Veg Items\n3. Non Veg Items \n4. Fetch Individual item\n5. Back\n");
				int option = Integer.parseInt(OrderHelper.switchValidator());
				switch (option) {
				case 1:
					statement = connect.prepareStatement(Constant.strreadallitemQuery);
					ResultSet rs = statement.executeQuery();
					while (rs.next()) {
						System.out.println(rs.getString("FId") + " " + rs.getString("FName") + " "
								+ rs.getString("FType") + " " + rs.getString("FPrice"));
					}
					System.out.println();
					break;

				case 2:
					statement = connect.prepareStatement(Constant.strreadItemVegQuery);
					ResultSet rs1 = statement.executeQuery();
					System.err.println("\nVeg Items");
					while (rs1.next()) {
						System.out.println(rs1.getString("FId") + " " + rs1.getString("FName") + " "
								+ rs1.getString("FType") + " " + rs1.getString("FPrice"));
					}
					System.out.println();
					break;

				case 3:
					statement = connect.prepareStatement(Constant.strreadItemNonVegQuery);
					ResultSet rs2 = statement.executeQuery();
					System.err.println("\nNon-Veg Items");
					while (rs2.next()) {
						System.out.println(rs2.getString("FId") + " " + rs2.getString("FName") + " "
								+ rs2.getString("FType") + " " + rs2.getString("FPrice"));

					}
					System.out.println();
					break;

				case 4:
					statement = connect.prepareStatement(Constant.strreadItemQuery);
					System.out.print("\nEnter the Item id : ");
					String itemqry = scan.next();
					statement.setString(1, itemqry);
					ResultSet rs3 = statement.executeQuery();
					while (rs3.next()) {
						System.out.println(rs3.getString("FId") + " " + rs3.getString("FName") + " "
								+ rs3.getString("FType") + " " + rs3.getString("FPrice"));
					}
					System.out.println();
					break;

				case 5:
					System.out.println();
					repeatflag = false;
					break;

				default:
					break;
				}
			}

			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Update the menu item price in the menu table in the database
	// based on food Id
	public static void updateItem() {

		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			boolean repeatFlag = true;
			while (repeatFlag) {
				System.out.print("\n1. Update Price \n2. Back \nChoose Option : ");
				int option = scan.nextInt();
				System.out.print("\nEnter the Food id : ");
				String FId = scan.nextLine();
				switch (option) {
				case 1:

					System.out.print("Enter the new Food Price : ");
					String price = scan.next();
					statement = connect.prepareStatement(Constant.updatePriceQuery);
					statement.setString(1, price);
					statement.setString(2, FId.toUpperCase());
					statement.executeUpdate();
					System.out.println("Successfully Updated Food Price.");
					break;

				case 2:
					repeatFlag = false;
					break;

				default:
					System.out.println("Invalid Emp Id!!!");
					break;
				}
			}

			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
