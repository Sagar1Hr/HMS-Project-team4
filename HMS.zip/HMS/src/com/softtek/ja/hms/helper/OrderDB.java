package com.softtek.ja.hms.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

import com.softtek.ja.hms.domain.Customer;
import com.softtek.ja.hms.domain.Order;
import com.softtek.ja.hms.operation.Hotel;
import com.softtek.ja.hms.operation.OrderOperation;

public class OrderDB {

	static Connection connect;
	static PreparedStatement statement, statement1, statement2, statement3;
	static Statement nstatement;
	static Customer cus;
	static Order or;
	static long cusMobile;

	public static ArrayList<Customer> cusdetails = new ArrayList<Customer>();
	public static Scanner scan = new Scanner(System.in);

	// Method to Take Order
	// selecting the food items and billing is done
	public static void takeOrder() {
		System.out.println("\nPlease Select the FoodId");

		System.out.println("What do you want to order");
		boolean orderFlag = true;
		while (orderFlag) {
			System.out.print("\n1 : Select/Add Item \n2 : Proceed with Bill\n3 : Cancel Order \n");
			int option = Integer.parseInt(OrderHelper.switchValidator());
			switch (option) {
			case 1:
				String item = OrderHelper.itemValidator();
				int quantity = Integer.parseInt(OrderHelper.quantityValidator());

				try {
					connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
					statement = connect.prepareStatement("select FId,FName,FPrice from menu where FId = ?");
					statement.setString(1, item);
					ResultSet rs1 = statement.executeQuery();
					rs1.next();
					String fId = rs1.getString("FId");
					String fName = rs1.getString("FName");
					double fPrice = rs1.getDouble("FPrice");
					double total = fPrice * quantity;

					statement1 = connect.prepareStatement("insert into items values(?,?,?,?,?)");
					statement1.setString(1, fId);
					statement1.setString(2, fName);
					statement1.setDouble(3, fPrice);
					statement1.setInt(4, quantity);
					statement1.setDouble(5, total);
					statement1.executeUpdate();

					rs1.close();
					statement1.close();
					connect.close();

				} catch (SQLException e) {
					e.printStackTrace();
				}

				break;
			case 2:
				try {
					connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
					Statement statement = connect.createStatement();
					ResultSet rs2 = statement.executeQuery("Select * from items");
					if (rs2.next() == true) {
						orderFlag = false;
						break;

					} else {
						System.out.println("Please select/add atleast one item to proceed with bill\n");
						break;
					}
				} catch (Exception e) {
					OrderDB.takeOrder();
				}

			case 3:
				finalTableListUpdate();
				OrderOperation.orders();
			}

		}

		DisplayfoodItems();

	}

	// Method to get the customer details form the console and Inserting the data to
	// the Customer Table in the database.
	public String[] takeCustomerDetails() {
		String[] values = new String[2];
		System.out.println("\nIs this your First time coming to our Hotel \n" + "1: No\n" + "2: Yes");
		int customerOption = Integer.parseInt(OrderHelper.switchValidator());
		switch (customerOption) {
		case 1:
			System.out.println("\n====================================");
			System.out.print("Please provide your Mobile Number\n");
			cusMobile = OrderHelper.MobileNumberValidation();
			try {
				Class.forName(Constant.DRIVER);
			} catch (ClassNotFoundException cnfe) {
				System.err.println("ClassNotFoundException : " + cnfe);
			}

			try {
				connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
				statement = connect.prepareStatement(Constant.READCustomerQuery);
				ResultSet rse = statement.executeQuery();
				while (rse.next()) {
					Customer cus = new Customer(rse.getString("CId"), rse.getString("cName"), rse.getString("cEmail"),
							rse.getString("cMobile"));
					cusdetails.add(cus);
				}
				for (int i = 0; i < cusdetails.size(); i++) {

					if (cusdetails.get(i).getcMobile() == cusMobile) {
						values[0] = cusdetails.get(i).getCustomerId();
						values[1] = cusdetails.get(i).getCustomerName();

						System.out.println("\n====================================");
						System.out.println("Welcome To Hotel ABC : " + cusdetails.get(i).getCustomerName());
						System.out.println("Please Proceed with your Order\n====================================");

						return values;
					}
				}
				statement.close();
				connect.close();

				return values;

			} catch (SQLException e) {
				e.printStackTrace();
			}

			break;
		case 2:

			System.out.println("=============================================================");
			System.out.println("\nPlease Provide Details");
			System.out.print("CName         : ");
			String cName = scan.next();
			String cEmail = OrderHelper.emailValidation();
			Long cMobile = OrderHelper.MobileNumberValidation();
			cus = new Customer(cName, cEmail, cMobile);

			try {
				Class.forName(Constant.DRIVER);
			} catch (ClassNotFoundException cnfe) {
				System.err.println("ClassNotFoundException : " + cnfe);
			}

			try {
				connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
				statement = connect.prepareStatement(Constant.CUSINSEERTQUERY);
				statement.setString(1, cus.getCustomerId());
				statement.setString(2, cus.getCustomerName());
				statement.setLong(3, cus.getcMobile());
				statement.setString(4, cus.getcEmail());
				statement.executeUpdate();
				System.out.println("Inserted Successfully");
				values[0] = cus.getCustomerId();
				values[1] = cus.getCustomerName();

				statement.close();
				connect.close();

				return values;

			} catch (SQLException e) {
				e.printStackTrace();
			}
		default:
			System.out.println("Invalid Option\n");
			takeCustomerDetails();
		}

		return values;

	}

	public static void readCustomer() {
		System.out.println("\nCustomer Details");
		System.out.println("\n======================================================");

		try {

			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			statement = connect.prepareStatement(Constant.READCustomerQuery);
			ResultSet rs1 = statement.executeQuery();
			System.out.println("CId  CName     CMobile        CMobile\n");
			while (rs1.next()) {
				String cid = rs1.getString("CId");
				String name = rs1.getString("cName");
				long mobile = Long.parseLong(rs1.getString("cMobile"));
				String email = rs1.getString("cEmail");
				System.out.printf("%-5s%-10s%d" + "     " + "%-20s \n", cid, name, mobile, email);
			}
			System.out.println("======================================================\n");
			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void readEmployee(String readAllquery) {
		String readquery = "select * from employee where EmpId=?";

		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			// Code to choose and display all the records, individual info or back to main
			boolean repeatflag = true;
			while (repeatflag) {
				System.out.print("1. Display All\n2. Fetch individual info \n3. Back \nChoose Option : ");
				int option = scan.nextInt();
				switch (option) {
				case 1:
					connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

					statement = connect.prepareStatement(Constant.READCustomerQuery);
					ResultSet rs1 = statement.executeQuery();
					System.out.println("CId  CName     CMobile        CMobile\n");
					while (rs1.next()) {
						String cid = rs1.getString("CId");
						String name = rs1.getString("cName");
						long mobile = Long.parseLong(rs1.getString("cMobile"));
						String email = rs1.getString("cEmail");
						System.out.printf("%-5s%-10s%d" + "     " + "%-20s \n", cid, name, mobile, email);
					}
					System.out.println("======================================================\n");
					statement.close();
					connect.close();

					break;
				case 2:
					statement = connect.prepareStatement(readquery);
					System.out.print("Enter the Customer id : ");
					String cusread = scan.next();
					statement.setString(1, cusread);
					ResultSet rs2 = statement.executeQuery();
					while (rs2.next()) {
						String cid = rs2.getString("CId");
						String name = rs2.getString("cName");
						long mobile = Long.parseLong(rs2.getString("cMobile"));
						String email = rs2.getString("cEmail");
						System.out.printf("%-5s%-10s%d" + "     " + "%-20s \n", cid, name, mobile, email);
					}
					statement.close();
					connect.close();

					break;
				case 3:
					repeatflag = false;
					break;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to display the data present in the Menu Table
	public static void MenuDisplay() {
		try {

			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			statement = connect.prepareStatement(Constant.strreadItemVegQuery);
			ResultSet rs1 = statement.executeQuery();
			System.out.println("\n====================================");
			System.out.println("Veg Items");
			System.out.println("====================================");

			System.out.println("Food_ID    Item_Name          Price");
			System.out.println("------------------------------------");
			while (rs1.next()) {
				System.out.printf("%-11s%-19s%-13s \n", rs1.getString("FId"), rs1.getString("FName"),
						rs1.getString("FPrice"));
			}
			System.out.println("");

			statement = connect.prepareStatement(Constant.strreadItemNonVegQuery);
			ResultSet rs2 = statement.executeQuery();
			System.out.println("\n====================================");
			System.out.println("Non-Veg Items");
			System.out.println("====================================");
			System.out.println("Food_ID    Item_Name          Price");
			System.out.println("------------------------------------");
			while (rs2.next()) {
				System.out.printf("%-11s%-19s%-13s \n", rs2.getString("FId"), rs2.getString("FName"),
						rs2.getString("FPrice"));
			}
			System.out.println("------------------------------------");
			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to display the TableList Table from the database
	// to check the availability
	public static void tableDisplay() {
		try {

			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			statement = connect.prepareStatement(Constant.TABLEDISPLAY);
			ResultSet rs1 = statement.executeQuery();
			System.out.println("\n---------------------------");
			System.out.println("Tables  Seats  Availibility");
			System.out.println("---------------------------");
			while (rs1.next()) {
				System.out.println(rs1.getString("TID") + "     " + rs1.getString("Seats") + "      "
						+ rs1.getString("Availibility"));
			}
			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to display the food items from the items table where the food items
	// selected by customer are temporarily stored in the items table.
	public static void DisplayfoodItems() {
		try {

			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			statement = connect.prepareStatement(Constant.ItemsDISPLAY);
			ResultSet rs1 = statement.executeQuery();
			System.err.println("\nItem           Price     Quantity     Total");
			while (rs1.next()) {

//				System.out.println(rs1.getString("FName") + "      " + rs1.getString("FPrice") + "      "
//						+ rs1.getString("Quantity") + "      " + rs1.getString("Total"));

				System.out.printf("%-15s%-10s%-13s%-15s \n", rs1.getString("FName"), rs1.getString("FPrice"),
						rs1.getString("Quantity"), rs1.getString("Total"));
			}
			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// Method to update the tableList table by changing the status of availability
	// By using the table Id
	public static void tableListUpdate(int tid, String status) {
		try {

			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement(Constant.tableListUpdateNAQuery);
			statement.setString(1, status);
			statement.setInt(2, tid);
			statement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// Method to update the final tableList table by changing the status of
	// availability
	public static void finalTableListUpdate() {
		try {

			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement(Constant.finaltableListUpdateQuery);
			statement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// Method to store the total items and the total cost of them in the bill table
	// First the order details are stored in a object and storing it into bill
	// table and then generating the bill by calculating all the taxes.
	public static void orderBill(int tId, String cid, String cName) {

		try {

			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			statement = connect.prepareStatement("SELECT SUM(Total) FROM items");

			ResultSet rs1 = statement.executeQuery();
			rs1.next();
			double t = rs1.getDouble("SUM(Total)");
			double total = t;
			or = new Order(tId, cid, cName, total);

			statement1 = connect.prepareStatement("insert into bill values(?,?,?,?,?,now())");

			statement1.setString(1, or.getOrderId());
			statement1.setString(2, or.getCustomerId());
			statement1.setInt(3, or.getTableId());
			statement1.setString(4, or.getCustomerName());
			statement1.setDouble(5, or.getTotalPrice());
			statement1.executeUpdate();

			statement2 = connect.prepareStatement("insert into orderhistory values(?,?,?,?,?,now())");

			statement2.setString(1, or.getOrderId());
			statement2.setString(2, or.getCustomerId());
			statement2.setInt(3, or.getTableId());
			statement2.setString(4, or.getCustomerName());
			statement2.setDouble(5, or.getTotalPrice());
			statement2.executeUpdate();

			getBill(or.getOrderId());

			statement.close();
			connect.close();

		} catch (SQLException e) {
			orderBill(tId, cid, cName);

		}
	}

	// Method to get the total bill from the bill table based on the order id and
	// calling the bill displayer method where bill is printed.
	public static void getBill(String OId) {

		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			statement1 = connect.prepareStatement("select * from bill where OId = ?");
			statement1.setString(1, OId);

			ResultSet rs1 = statement1.executeQuery();
			rs1.next();
			double total = rs1.getDouble(5);
			String oid = rs1.getString("OId");
			String Cid = rs1.getString("CId");
			int tid = rs1.getInt("TId");
			String cName = rs1.getString("cName");
			String time = rs1.getString("Time");

			billdisplayer(total, oid, Cid, tid, cName, time);

			statement1.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to display the bill and getting the fully modified bill on the console
	public static void billdisplayer(double total, String oid, String cid, int tid, String cName, String time) {

		final DecimalFormat df = new DecimalFormat("0.00");
		double cgst = (Constant.CGST / 100) * total;
		double sgst = (Constant.SGST / 100) * total;
		double totalBill = total + cgst + sgst;
		Hotel hotel = new Hotel();
		System.out.println("\n----------------------------------------------");
		hotel.displayHotelDetails();
		System.out.println("\n==============================================");

		System.out.println("                     Bill");
		System.out.println("----------------------------------------------\n");
		System.out.println("Date and Time     : " + time);
		System.out.println("Order Id          : " + oid);
		System.out.println("Table Id          : " + tid);
		System.out.println("Customer-Id       : " + cid);
		System.out.println("Customer-Name     : " + cName);
		DisplayfoodItems();

		System.out.println("\n----------------------------------------------");
		System.out.println("Gross Bill   :           " + "SGST(" + Constant.SGST + ")  : " + sgst
				+ "\n                        " + " CGST(" + Constant.CGST + ")  : " + cgst);
		System.out.println("==============================================");
		System.out.println("                         " + "Total      : " + df.format(totalBill));
		System.out.println("==============================================\n");
		System.out.println("Have A Nice Day " + cName + " \nPlease Visit Again");
		System.out.println("\n==============================================\n");
		feedback(cid, cName);

		finalTableListUpdate();

		System.out.println("==============================================\n");

	}

	// Method to clear all the data in the items(Dummy table) table
	// that the next customer can order the food again
	public static void clearItems() {
		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			statement = connect.prepareStatement("DELETE FROM items");
			statement.executeUpdate();

			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void clearBillTable() {
		try {
			connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");

			statement = connect.prepareStatement("DELETE FROM bill");
			statement.executeUpdate();

			statement.close();
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void feedback(String CId, String cName) {
		System.out.println("Would you like to share your feedback");
		System.out.println("1 : Yes\n2 : No");
		int feedbackOption = Integer.parseInt(OrderHelper.switchValidator());
		if (feedbackOption == 1) {
			System.out.println("\nPlease Provide your Feedback\n============================");
			System.out.println("5 : Excellent\n4 : VeryGood\n3 : Good\n2 : Average\n1 : Poor");
			System.out.print("Your Ratings : ");
			String str = scan.next();
			String regex = "[0-9]";
			System.out.println("Feedback : ");
			scan.nextLine();
			String feedback = scan.nextLine();
			if (str.matches(regex)) {
				int rating = Integer.parseInt(str);
				try {
					connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
					statement = connect.prepareStatement(Constant.insertfeedbackQUERY);
					statement.setString(1, CId);
					statement.setInt(2, rating);
					statement.setString(3, feedback);

					statement.executeUpdate();
					System.out.println("Thank You for your Feedback " + cName);
					System.out.println("");

				} catch (SQLException e) {
					System.out.println("\nInvalid feedback\n");
					feedback(CId, cName);
				}
			} else {
				System.out.println("\nplease provide valid ratings\n");
				feedback(CId, cName);
			}

		}

	}
}
