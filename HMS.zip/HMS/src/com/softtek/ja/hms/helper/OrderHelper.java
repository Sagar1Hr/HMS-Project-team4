package com.softtek.ja.hms.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class OrderHelper {
	public static int tab = 0;
	static Scanner scanner = new Scanner(System.in);

	public static String emailValidation() {

		System.out.print("CEmail        : ");
		String id = scanner.nextLine();
		System.out.println();
		String res = "No Email";
		boolean eFlag = true;

		while (eFlag) {
			if (checkEmail(id) == true) {
				eFlag = false;
				return res = id;
			} else {
				System.out.println("Invalid Email\nEnter valid Email");
				System.out.print("CEmail        : ");
				id = scanner.nextLine();
			}
		}
		return res;
	}

	public static long MobileNumberValidation() {
		System.out.print("Mobile No     : ");
		long mobile = 0l;
		String mobNo = scanner.next();
		if (mobNo.length() == 10 && mobNo.matches("[0-9]*")) {
			mobile = Long.parseLong(mobNo);
			return mobile;
		} else {
			System.out.println("\nInvalid Mobile Number");
			MobileNumberValidation();
		}
		return mobile;
	}

	public static boolean checkEmail(String id) {
		if (id.matches("[A-Za-z0-9+_.-]+@[A-za-z]+.[com]*")) {

			return true;
		} else {
			return false;
		}
	}

	public static int validateTab() {

		try {
			Connection connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			@SuppressWarnings("resource")
			Scanner scan = new Scanner(System.in);
			System.out.print("Table Number : ");
			try {
				tab = scan.nextInt();
			} catch (Exception e) {
				System.out.println("\nPlease enter valid table number");
				validateTab();
			}

			PreparedStatement statement = connect.prepareStatement("SELECT Availibility FROM tablelist where TID = ? ");
			PreparedStatement statement1 = connect.prepareStatement(Constant.getLastTableId);
			statement.setInt(1, tab);
			ResultSet rs = statement.executeQuery();
			rs.next();
			try {
				String tab1 = rs.getString("Availibility");
				if (tab1.equals("yes")) {
					ResultSet rs1 = statement1.executeQuery();
					rs1.next();
					if (tab > 100 && tab <= rs1.getInt("TID")) {
						return tab;
					} else {
						System.out.print("\nTable do not Exsists\n");
						validateTab();
					}
				} else {
					System.out.print("\nTable already Occupied\n");
					validateTab();

				}
			} catch (Exception e) {
				System.out.println("\nPlease enter valid table number");
				validateTab();
			}

		} catch (SQLException e) {
			System.out.println("\nPlease enter valid table number");
			validateTab();
		}

		return 0;
	}

	public static String switchValidator() {
		System.out.println("\nChoose Option : ");
		String option = scanner.next();
		String regex = "[1-9]";
		if (option.matches(regex)) {
			return option;
		} else {
			System.out.println("Invalid option");
		}

		return switchValidator();
	}
	
	public static String quantityValidator() {
		System.out.println("Quantity : ");
		String option = scanner.next();
		String regex = "[1-9]";
		if (option.matches(regex)) {
			return option;
		} else {
			System.out.println("\nInvalid option");
		}

		return quantityValidator();
	}

	public static String AmountValidator() {
		System.out.println("\nAmount : ");
		String option = scanner.next();
		String regex = "^[1-9]\\d*(\\.\\d+)?$";
		if (option.matches(regex)) {
			return option;
		} else {
			System.out.println("Invalid option");
		}

		return AmountValidator();
	}

	public static String MobileValidator() {
		System.out.print("\nMobile : ");
		String option = scanner.nextLine();
		String regex = "^^\\+?[0-9-]+$";
		if (option.matches(regex)) {
			return option;
		} else {
			System.out.println("Invalid Mobile");
		}

		return MobileValidator();
	}

	public static String itemValidator() {
		System.out.print("\nItem Id : ");
		String item = scanner.next();
		try {
			Connection connect = DriverManager.getConnection(Constant.URL, "root", "Softtek@2022");
			PreparedStatement statement = connect.prepareStatement("select FId from menu where FId = ?");
			statement.setString(1, item);
			ResultSet rs = statement.executeQuery();
			if (rs.next() == true) {
				return item;
			} else {
				System.out.println("Invalid Item Number...\nPlease select iTem number which are in Menu ");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return itemValidator();
	}
	public static String nameValidator() {
		System.out.print("Name         : ");
		String option = scanner.nextLine();
		String regex = "^[a-zA-Z][a-zA-Z0-9_]{2,19}$";
		if (option.matches(regex)) {
			return option;
		} 
		else 
		{
			System.out.println("Invalid Name\n");
		}

		return nameValidator();
	}
//	 public static String isName(String name) 
//	 {
//		System.out.print("NAME         : ");
//        Pattern ptrn = Pattern.compile("^[a-zA-Z][a-zA-Z0-9_]{2,19}$");
//        Matcher match = ptrn.matcher(name);
//        return match.matches();
//    }

}
