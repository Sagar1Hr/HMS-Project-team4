package com.softtek.ja.hms.interfaces;

public interface IOperations 
{
	public void add();

	public void delete();

	public void update();
	
	public void read();
}
