package com.softtek.ja.hms.operation;

import java.util.Scanner;

import com.softtek.ja.hms.helper.FinanceDB;
import com.softtek.ja.hms.helper.FinanceHelper;
import com.softtek.ja.hms.helper.OrderHelper;

public class FinanceOperation {

	Scanner scan = new Scanner(System.in);

	public void financeLogin() {
		System.out.print("User     : ");
		String user = scan.nextLine();
		System.out.print("Password : ");
		String password = scan.nextLine();
		if (FinanceHelper.financeLoginValidator(user, password)) {
			openFinancePortal();
		} else {
			System.out.println("Please provide valid Username and Password");
			financeLogin();
		}
	}

	public void openFinancePortal() {
		boolean financeFlag = true;
		while (financeFlag) {
			System.out.println("------------------------------------");
			System.out.println("Welcome to Finance Portal");
			System.out.println("------------------------------------\nWhere would you like to proceed"
					+ "\n1 : Get Finance Report " + "\n2 : Update Finance Details " + "\n3 : Back to Main");
			int financeOption = Integer.parseInt(OrderHelper.switchValidator());
			switch (financeOption) {
			case 1:
				new FinanceDB().getFinaceReport();
				break;

			case 2:
				new FinanceDB().updateFinaceReport();
				break;

			case 3:
				financeFlag = false;
				break;

			default:
				financeFlag = false;
				openFinancePortal();
				break;
			}
			System.out.println("------------------------------------");
		}

	}
}
