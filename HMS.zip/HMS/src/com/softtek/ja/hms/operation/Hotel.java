package com.softtek.ja.hms.operation;

import java.util.Scanner;

import com.softtek.ja.hms.helper.AdminHelper;
import com.softtek.ja.hms.helper.OrderHelper;

//Starting of the project from the Hotel Class
public class Hotel {

	// All the Instance variables of the Hotel Class
	public static String strHotelName = "HOTEL ABC";
	public static long lgMobileNo = 7892442572l;
	public static String strEmail = "abc@hotel.com";
	public static String strAddress = "Bommanahalli";

	// All getter Methods of the Hotel Class Instance Variables
	public String getStrHotelName() {
		return strHotelName;
	}

	public long getLgMobileNo() {
		return lgMobileNo;
	}

	public String getStrEmail() {
		return strEmail;
	}

	public String getStrAddress() {
		return strAddress;
	}

	@Override
	public String toString() {
		return strHotelName + lgMobileNo + strEmail + strAddress;
	}

	public void hotelExecute() {
		displayHotelDetails();
		hotelOpen();
	}

	// Main Execution work flow Starts from the hotelOpen Method
	// We will check that if the hotel is opened in the particular time or not.
	// If its open the program further execution will proceed or exits from the
	// program.
	public void hotelOpen() {
		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		while (flag) {
//			System.out.println("===================================\n");
			// Condition to choose whether to go to to Admin Operation or Order Operation or
			// Exit the Code/LogOut
			if (AdminHelper.open()) {
				System.out.print("1. Admin \n2. Orders\n3. Finance\n4. Exit\n");
				int startOption = Integer.parseInt(OrderHelper.switchValidator());
				switch (startOption) {
				case 1:
					HotelOperation.login();
					break;
				case 2:
					OrderOperation.orders();
					break;
				case 3:
					new FinanceOperation().openFinancePortal();
					break;
				case 4:
					java.lang.System.exit(0);
				default:
					System.out.println("Invalid option");
					break;
				}

			} else {
				System.out.println("Have A Nice Day");
				java.lang.System.exit(0);
			}
		}
		sc.close();

	}

	// Method to display all the details
	public void displayHotelDetails() {
		System.out.println("                 " + strHotelName);
		System.out.println("----------------------------------------------");
		System.out.println("Address :  " + strAddress);
		System.out.println("Email   :  " + strEmail);
		System.out.println("Contact :  " + lgMobileNo);
		System.out.println("----------------------------------------------");
	}
}
