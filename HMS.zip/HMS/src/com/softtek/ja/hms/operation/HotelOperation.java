package com.softtek.ja.hms.operation;

import java.util.Scanner;
import com.softtek.ja.hms.domain.Accountant;
import com.softtek.ja.hms.domain.Admin;
import com.softtek.ja.hms.domain.Chef;
import com.softtek.ja.hms.domain.Maintainance;
import com.softtek.ja.hms.domain.NonVeg;
import com.softtek.ja.hms.domain.Server;
import com.softtek.ja.hms.domain.Veg;
import com.softtek.ja.hms.helper.AdminHelper;
import com.softtek.ja.hms.helper.OrderHelper;

public class HotelOperation extends Hotel {
	// All the object references for the domain classes
	static Server svr = new Server();
	static Chef chf = new Chef();
	static Maintainance mtn = new Maintainance();
	static Veg v = new Veg();
	static Hotel hotel = new Hotel();
	static NonVeg nv = new NonVeg();
	static Accountant acc = new Accountant();
	static Admin adm = new Admin();

	// Scanner Class declaration
	static Scanner scan = new Scanner(System.in);

	// Login() to perform the login method for the
	public static void login() {

		// User Inputs are taken using the scanner class
		System.out.print("User     : ");
		String user = scan.next();
		System.out.print("Password : ");
		String password = scan.next();

		// Validating the admin Login details
		if (AdminHelper.loginValidation(user, password)) {
			boolean mainFlag = true;
			while (mainFlag) {
				System.out.println("\nWHERE do u want to go");
				System.out.print("1 : Employee Portal\n2 : Items\n3 : Back To Main\n");
				int firstOption = Integer.parseInt(OrderHelper.switchValidator());

				// Code to choose whether to choose the Employee Portal or Items or Back to main
				switch (firstOption) {

				case 1:
					boolean mainFlag2 = true;
					while (mainFlag2) {
						System.out.println("\n Where do you want to go");
						System.out.print(
								"1 : Server Record\n2 : Chef Record\n3 : Maintainance Record\n4 : Accountant Record\n5 : Admin\n6 : Back\n");
						int secondOption = Integer.parseInt(OrderHelper.switchValidator());

						// Code to choose whether to choose the Server or Chef or maintainance records
						switch (secondOption) {
						case 1:
							boolean serverFlag = true;
							while (serverFlag) {
								System.out.print(
										"1 : Add Server Record\n2 : Delete Server Record\n3 : Update Server Details\n4 : Fetch Server Details\n5 : Back\n6 : LogOut\n");
								int serverOption = Integer.parseInt(OrderHelper.switchValidator());

								// Code to Choose which Crud Operation to Perform on Server Records
								switch (serverOption) {
								case 1:
									svr.add();
									break;
								case 2:
									svr.delete();
									break;
								case 3:
									svr.update();
									break;
								case 4:
									svr.read();
									break;
								case 5:
									serverFlag = false;
									break;
								case 6:
									hotel.hotelOpen();
									break;
								default:
									System.out.println("Invalid Option");
									break;
								}
							}

							break;

						case 2:
							boolean chefFlag = true;
							while (chefFlag) {
								System.out.print(
										"1 : Add Chef Record\n2 : Delete Chef Record\n3 : Update Chef Details\n4 : Fetch Chef Details\n5 : Back\n6 : LogOut\n");
								int chefOption = Integer.parseInt(OrderHelper.switchValidator());

								// Code to Choose which Crud Operation to Perform on Chef Records
								switch (chefOption) {
								case 1:
									chf.add();
									break;
								case 2:
									chf.delete();
									break;
								case 3:
									chf.update();
									break;
								case 4:
									chf.read();
									break;
								case 5:
									chefFlag = false;
									break;
								case 6:
									hotel.hotelOpen();
									break;
								default:
									System.out.println("Invalid Option");
									break;
								}
							}

							break;

						case 3:
							boolean maintainFlag = true;
							while (maintainFlag) {
								System.out.print(
										"1 : Add Maintanance Record\n2 : Delete Maintanance Record\n3 : Update Maintanance Details\n4 : Fetch Maintainance Details\n5 : Back\n6 : LogOut\6 : LogOut\n");
								int mtnOption = Integer.parseInt(OrderHelper.switchValidator());

								// Code to Choose which Crud Operation to Perform on Maintanance Records
								switch (mtnOption) {
								case 1:
									mtn.add();
									break;
								case 2:
									mtn.delete();
									break;
								case 3:
									mtn.update();
									break;
								case 4:
									mtn.read();
									break;
								case 5:
									maintainFlag = false;
									break;
								case 6:
									hotel.hotelOpen();
									break;
								default:
									System.out.println("Invalid Option");
									break;
								}
							}

							break;
						case 4:
							boolean accFlag = true;
							while (accFlag) {
								System.out.print(
										"1 : Add Accountant Record\n2 : Delete Accountant Record\n3 : Update Accountant Details\n4 : Fetch Accountant Details\n5 : Back\n6 : LogOut\n");
								int accOption = Integer.parseInt(OrderHelper.switchValidator());

								// Code to Choose which Crud Operation to Perform on Accountant Records
								switch (accOption) {
								case 1:
									acc.add();
									break;
								case 2:
									acc.delete();
									break;
								case 3:
									acc.update();
									break;
								case 4:
									acc.read();
									break;
								case 5:
									accFlag = false;
									break;
								case 6:
									hotel.hotelOpen();
									break;
								default:
									System.out.println("Invalid Option");
									break;
								}
							}

							break;
						case 5:
							boolean adminFlag = true;
							while (adminFlag) {
								System.out.print(
										"1 : Add Admin Record\n2 : Delete Admin Record\n3 : Update Admin Details\n4 : Fetch Admin Details\n5 : Back\n6 : LogOut\n");
								int adminOption = Integer.parseInt(OrderHelper.switchValidator());

								// Code to Choose which Crud Operation to Perform on Admin Records
								switch (adminOption) {
								case 1:
									adm.add();
									break;
								case 2:
									adm.delete();
									break;
								case 3:
									adm.update();
									break;
								case 4:
									adm.read();
									break;
								case 5:
									adminFlag = false;
									break;
								case 6:
									hotel.hotelOpen();
									break;
								default:
									System.out.println("Invalid Option");
									break;
								}
							}

							break;
						case 6:
							mainFlag2 = false;
							break;
						}
					}
					break;

				case 2:
					boolean mainFlag3 = true;
					while (mainFlag3) {
						System.out.println("\n Where do you want to go");
						System.out.print(
								"1 : VEG Record\n2 : NonVEG Record\n3 : Display Items\n4 : Update Items \n5 : Back\n");
						int secondOption1 = Integer.parseInt(OrderHelper.switchValidator());

						// Code to choose to go to VEG , NONVEG , DISPLAY ITEMS , UPDATE ITEMS , Back
						switch (secondOption1) {
						case 1:

							// Code to Choose Which CRUD operation to perform
							boolean vegFlag = true;
							while (vegFlag) {
								System.out.print(
										"1 : Add VegItem Record\n2 : Delete VegItem Record\n3 : Back\n4 : LogOut\n");
								int vegOption = Integer.parseInt(OrderHelper.switchValidator());
								switch (vegOption) {
								case 1:
									v.add();
									break;
								case 2:
									v.delete();
									break;
								case 3:
									vegFlag = false;
									break;
								case 4:
									hotel.hotelOpen();
									break;
								default:
									System.out.println("Invalid Option");
									break;
								}
							}

							break;
						case 2:

							// Code to Choose Which CRUD operation to perform
							boolean nonVegFlag = true;
							while (nonVegFlag) {
								System.out.print(
										"1 : Add NonVegItem Record\n2 : Delete NonVegItem Record\n3 : Back\n4 : LogOut\n");
								int nVegOption = Integer.parseInt(OrderHelper.switchValidator());
								switch (nVegOption) {
								case 1:
									nv.add();
									break;
								case 2:
									nv.delete();
									break;
								case 3:
									nonVegFlag = false;
									break;
								case 4:
									hotel.hotelOpen();
									break;
								default:
									System.out.println("Invalid Option");
									break;
								}
							}
							break;

						case 3:
							v.read();
							break;

						case 4:
							v.update();
							break;

						case 5:
							mainFlag3 = false;
							break;
						}
					}
					break;
				case 3:
					mainFlag = false;
					break;
				}
			}

		}

	}

}
