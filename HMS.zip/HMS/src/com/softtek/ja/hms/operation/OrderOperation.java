package com.softtek.ja.hms.operation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.softtek.ja.hms.domain.Customer;
import com.softtek.ja.hms.helper.OrderDB;
import com.softtek.ja.hms.helper.OrderHelper;

public class OrderOperation {
	static Scanner scan = new Scanner(System.in);
	public static int table;
	public static Customer cus;
	public static Connection connect;

	// Method to perform all the Order Operations
	public static void orders() {

		// Clearing all the dummy table items
		OrderDB.clearItems();
		boolean orderFlag = true;
		while (orderFlag) {
			System.out.println("\nWelcome To Order Portal");
			System.out.println("1 : Order\n2 : Back To Main");
			int orderOption = Integer.parseInt(OrderHelper.switchValidator());
			switch (orderOption) {
			case 1:
				// To display all the Table availability data
				OrderDB.tableDisplay();
				System.out.println("\nPlease select which available table you want");

				int tab = OrderHelper.validateTab();
				table = tab;
				OrderDB.tableListUpdate(tab, "no");
				String[] cvalues = new OrderDB().takeCustomerDetails();
				OrderDB.MenuDisplay();

				// Calling the Method to Take order
				OrderDB.takeOrder();
				

				System.out.println("\n==============================================\n");
				// Code to proceed with the billing
				boolean orderFlag1 = true;
				while (orderFlag1) {
					System.out.println("Would you Like to Proceed with your order");
					System.out.println("\n1 : Confirm Bill\n2 : Cancel order \n3 : Back To Main\n");
					int key = Integer.parseInt(OrderHelper.switchValidator());
					switch (key) {
					case 1:

						// calling the method to generate the bill
						OrderDB.orderBill(tab, cvalues[0], cvalues[1]);
						break;
					case 2:
						OrderDB.clearItems();
						System.out.println("\nOrder Cancelled");
						System.out.println("\nPlease Order Again");
						OrderDB.tableListUpdate(table, "yes");
						orderFlag1 = false;
						break;
					case 3:

						// Method calling to Update the table availability
						OrderDB.tableListUpdate(table, "yes");
						orderFlag = false;
						OrderDB.clearItems();
						break;

					default:
						System.out.println("\nInvalid Option\n");
					}

					// At the end clearing dummy table data
					OrderDB.clearItems();
					break;
				}

			case 2:
				orderFlag = false;
				new Hotel().hotelOpen();
				break;

			default:
				System.out.println("\nInvalid Option\n");
				orders();
				break;
			}
		}

	}

}
